using Microsoft.VisualStudio.TestPlatform.PlatformAbstractions.Interfaces;
using NUnit.Framework;

using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System.Threading;


namespace MauricioVimos
{
    public class Tests
    {
        public IWebDriver driver = new ChromeDriver(@"C:\Users\mau_v\source\repos\MauricioVimos\chromedriver.exe");

        public string url = "https://admin-sysnnova.com/OpenFact/Account/Login.aspx";



        [Test]
        public void RegistroDatos()
        {

            ITakesScreenshot ScreenShotDrive = driver as ITakesScreenshot;

            Screenshot screenshot = ScreenShotDrive.GetScreenshot();

            driver.Navigate().GoToUrl(url);

            driver.Manage().Window.Maximize();

            driver.FindElement(By.Id("LoginUser_UserName"));
            driver.FindElement(By.Id("LoginUser_UserName")).SendKeys("demo");

            driver.FindElement(By.Id("LoginUser_Password"));
            driver.FindElement(By.Id("LoginUser_Password")).SendKeys("0430");

            screenshot = ScreenShotDrive.GetScreenshot();
            screenshot.SaveAsFile(@"C:\Users\mau_v\source\repos\MauricioVimos\" + " LogueoOK "+ ".png");

            Thread.Sleep(8000);

            driver.FindElement(By.Id("LoginUser_LoginButton")).Click();

            Thread.Sleep(8000);

            driver.FindElement(By.Id("liClientes")).Click();

            Thread.Sleep(4000);

            driver.FindElement(By.Id("MainContent_btnAdd")).Click();
            Thread.Sleep(2000);

            ///llenar formulario
            driver.FindElement(By.Id("MainContent_txtNombreCliente")).SendKeys("MAURICIO GABRIEL VIMOS MALDONADO");
            driver.FindElement(By.Id("MainContent_txtIdentificacion")).SendKeys("0104775333");
            driver.FindElement(By.Id("MainContent_txtTelefonoConvencional")).SendKeys("0995514630");
            driver.FindElement(By.Id("MainContent_txtTelefonoCelular")).SendKeys("0995514630");
            driver.FindElement(By.Id("MainContent_txtDireccion")).SendKeys("RACAR");
            driver.FindElement(By.Id("MainContent_txtMailDefecto")).SendKeys("mvimos@sistec.com.ec");

            var tipoident = driver.FindElement(By.Id("MainContent_ddlTipoIdentificacion"));
            var selectelement = new SelectElement(tipoident);
            selectelement.SelectByValue("05");
            Thread.Sleep(2000);

            IWebElement check1 = driver.FindElement(By.Id("MainContent_cbxEnviarBienvenida"));
            check1.Click();

            screenshot = ScreenShotDrive.GetScreenshot();
            screenshot.SaveAsFile(@"C:\Users\mau_v\source\repos\MauricioVimos\" + " LlenadoDatos " + ".png");

            Thread.Sleep(8000);

            driver.FindElement(By.Id("MainContent_btnGuardarCliente")).Click();

            screenshot = ScreenShotDrive.GetScreenshot();
            screenshot.SaveAsFile(@"C:\Users\mau_v\source\repos\MauricioVimos\" + " Guardar " + ".png");

            Thread.Sleep(5000);

            driver.SwitchTo().Alert().Accept();

            screenshot = ScreenShotDrive.GetScreenshot();
            screenshot.SaveAsFile(@"C:\Users\mau_v\source\repos\MauricioVimos\" + " AceptarModal " + ".png");

            Thread.Sleep(10000);

            screenshot = ScreenShotDrive.GetScreenshot();
            screenshot.SaveAsFile(@"C:\Users\mau_v\source\repos\MauricioVimos\" + " RegistroGrabado " + ".png");

            driver.Quit();
        }
    }
}